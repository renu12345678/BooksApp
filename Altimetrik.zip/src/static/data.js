
import android from './images/android.jpg';
import es6 from './images/es6.jpg'
import ng2 from './images/ng2.jpg'
export default [
    {
        id:'1',
        title:'Android',
        cost:12,
        isbn:68736875,
        picture:android
    },
    {
        id:'2',
        title:'ES6 & Beyond',
        cost:21,
        isbn:98480214,
        picture:es6
    },
    {
        id:'3',
        title:'ng-book-2',
        cost:14,
        isbn:32945781,
        picture:ng2
    }
]